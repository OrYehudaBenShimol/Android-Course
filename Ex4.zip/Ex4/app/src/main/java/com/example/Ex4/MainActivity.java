package com.example.Ex4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private String operand1 ;
    private String operand2 ;
    private String operation ;
    private String result ;
    private TextView resText;
    private TextView operSym;
    private TextView ExampleTxt;
    private EditText Et1 ;
    private EditText Et2 ;
    private Button mul;
    private Button div;
    private Button plus;
    private Button sub;
    private Button eq;
    private Button clear;
    private SeekBar seek;
    private  Context context;
    ViewGroup parentLayout;
    private boolean flag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Et1= (EditText) findViewById(R.id.editTextNumber);
        Et2 = (EditText) findViewById(R.id.editTextNumber2);
        clear = (Button) findViewById(R.id.button);
        clear.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {
                clearVal(view);
            }
        });

        mul = (Button) findViewById(R.id.button2);
        mul.setEnabled(false);
        mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                multiplication(view);
            }
        });

        div = (Button) findViewById(R.id.button3);
        div.setEnabled(false);
        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                divide(view);

            }
        });

        plus = (Button) findViewById(R.id.button4);
        plus.setEnabled(false);
        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                add(view);
            }
        });

        sub = (Button) findViewById(R.id.button5);
        sub.setEnabled(false);
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                subtract(view);
            }
        });

        Et1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if(!TextUtils.isEmpty(Et1.getText().toString()) && !TextUtils.isEmpty(Et2.getText().toString())){
                        enableAllButton();
                        if(Double.valueOf(Et2.getText().toString()) == 0){
                            div.setEnabled(false);
                    }
                }
                else disableAllButton();
            }
        });

        Et2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }
            @Override
            public void afterTextChanged(Editable editable) {
                if(!TextUtils.isEmpty(Et2.getText().toString()) && !TextUtils.isEmpty(Et1.getText().toString())){
                    double a = Double.valueOf(Et2.getText().toString());
                    enableAllButton();
                    if(a == 0) {
                        div.setEnabled(false);
                        }
                }
                else disableAllButton();
            }
        });



//        /*INFLATER CODE - START*/
//        int orientation = getResources().getConfiguration().orientation;
//        if (orientation == Configuration.ORIENTATION_PORTRAIT) {
//            parentLayout =(ViewGroup)findViewById(R.id.linear_layout1);
//        } else {
//            parentLayout =(ViewGroup)findViewById(R.id.linear_layout_landscape);
//        }
//        View child = getLayoutInflater().inflate(R.layout.seekbar_layout, parentLayout , false);
//        ConstraintLayout.LayoutParams rlp = new ConstraintLayout.LayoutParams(ViewGroup.LayoutParams. WRAP_CONTENT ,ViewGroup.LayoutParams. WRAP_CONTENT);
//        parentLayout.addView(child,rlp);
//        /*INFLATER CODE - END*/




        resText = (TextView) findViewById(R.id.textView5);
        operSym = (TextView) findViewById(R.id.textView6);
        ExampleTxt = (TextView) findViewById(R.id.textView100);
        seek = (SeekBar)findViewById(R.id.seekbar);
//        seek.setEnabled(false);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            Float tempRes=0f;
            String tempTxt="";
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                if(!TextUtils.isEmpty(resText.getText().toString())){
                    tempRes = Float.valueOf(resText.getText().toString());
                    if(i==0){
                        ExampleTxt.setText("Example: " + String.valueOf(tempRes.intValue()));
                        resText.setText(String.valueOf(tempRes.intValue()));
                    }
                    if(i ==1){
                        ExampleTxt.setText("Example: " + String.format("%.1f",tempRes));
                        resText.setText( String.format("%.1f",tempRes));
                    }
                    if(i ==2){
                        ExampleTxt.setText("Example: " + String.format("%.2f",tempRes));
                        resText.setText( String.format("%.2f",tempRes));
                    }
                    if(i ==3){
                        ExampleTxt.setText("Example: " + String.format("%.3f",tempRes));
                        resText.setText( String.format("%.3f",tempRes));
                    }
                    if(i ==4){
                        ExampleTxt.setText("Example: " + String.format("%.4f",tempRes));
                        resText.setText( String.format("%.4f",tempRes));
                    }
                    if(i ==5){
                        ExampleTxt.setText("Example: " + String.format("%.5f",tempRes));
                        resText.setText( String.format("%.5f",tempRes));
                    }
                }
//                else
//                    seek.setEnabled(false);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


        context = getApplicationContext();

    }


    public void disableAllButton(){
        div.setEnabled(false);
        mul.setEnabled(false);
        sub.setEnabled(false);
        plus.setEnabled(false);
    }
    public void enableAllButton(){
        div.setEnabled(true);
        mul.setEnabled(true);
        sub.setEnabled(true);
        plus.setEnabled(true);
    }

    @Override
    public void onSaveInstanceState(Bundle outState)
    {
        outState.putString("res",resText.getText().toString());
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState)
    {
        super.onRestoreInstanceState(savedInstanceState);
        resText.setText(savedInstanceState.getString("res"));

    }

    public void editTextBox1(View v){
        operand1 = Et1.getText().toString();
    }
    public void editTextBox2(View v){
        operand2 = Et2.getText().toString();
    }

     public void multiplication(View v){
        operation = "X";
         operSym.setText(operation);
         calculate(operation);
     }

    public void divide(View v){
        operation = "div";
        operSym.setText("/");
        calculate(operation);
    }

    public void add(View v){
        operation = "+";
        operSym.setText(operation);
        calculate(operation);
    }

    public void subtract(View v){
        operation = "-";
        operSym.setText(operation);
        calculate(operation);
    }

    public void clearVal(View v){
        operand1 ="";
        operand2="";
        operation="";
        result="";
        Et1.setText("");
        Et2.setText("");
        resText.setText("");
        operSym.setText("");
        disableAllButton();
        seek.setProgress(0);
        ExampleTxt.setText("Example: ");
//        seek.setEnabled(false);
        Toast toast = Toast.makeText(context,"Cleared!",Toast.LENGTH_SHORT);
        toast.show();
    }

    public void calculate(String op){
        operand1 = Et1.getText().toString();
        operand2 = Et2.getText().toString();
        if(operand1.length()>0 && operand2.length()>0 ){
            if(op == "div"  && Double.valueOf(operand2) == 0){
                Toast toast = Toast.makeText(context,"You Can't divide by zero",Toast.LENGTH_SHORT);
                toast.show();
                operSym.setText("");
            }
            else{
                if(op.equals("X") ){
                    result= String.valueOf((Double.valueOf(operand1) * Double.valueOf(operand2)));
                    resText.setText(result);
                }

                if(op.equals("div")){
                    result = String.valueOf(Double.valueOf(operand1) / Double.valueOf(operand2));
                    resText.setText(result);
                }

                if(op.equals("+")){
                    result =String.valueOf(Double.valueOf(operand1) + Double.valueOf(operand2));
                    resText.setText(result);
                }

                if(op.equals("-")){
                    result =String.valueOf(Double.valueOf(operand1) - Double.valueOf(operand2));
                    resText.setText(result);
                }
            }
            seek.setEnabled(true);
            Float tmp = Float.valueOf(result);
            ExampleTxt.setText("Example: " + String.valueOf(tmp.intValue()));
        }
        else{
            operSym.setText("");
            Toast toast = Toast.makeText(context,"Missing operands.",Toast.LENGTH_SHORT);
            toast.show();
        }
    }


    public int dp2px(int dp){
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        float px = dp * ((float) metrics.densityDpi / DisplayMetrics.DENSITY_DEFAULT);
        return (int)px;
    }

}