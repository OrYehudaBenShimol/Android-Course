package com.example.lab9;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private BroadcastReceiver brdReceiver = new NetworkReceiver();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dangerousPermission(Manifest.permission.READ_SMS);
        dangerousPermission(Manifest.permission.RECEIVE_SMS);
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(brdReceiver, filter, Manifest.permission.ACCESS_NETWORK_STATE, null);

    }

    @Override
    protected void onDestroy () {
        super.onDestroy();
        unregisterReceiver(brdReceiver);
    }


    private void dangerousPermission(String permission)
    {
        if (ContextCompat.checkSelfPermission(
                this, permission) == PackageManager.PERMISSION_GRANTED) {
                return;
        } else if (shouldShowRequestPermissionRationale(permission)) {
            Toast.makeText(this, "You need to grant permission to sms.", Toast.LENGTH_LONG).show();
        }
        requestPermissionLauncher.launch(permission);

    }

    // Register the permissions callback, which handles the user's response to the
    // system permissions dialog. Save the return value, an instance of
    // ActivityResultLauncher, as an instance variable.
    private ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    Toast.makeText(this, "Permission Granted!", Toast.LENGTH_SHORT).show();
                    return;
                } else {

                }
            });
}