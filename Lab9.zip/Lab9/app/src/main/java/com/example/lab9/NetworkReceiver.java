package com.example.lab9;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.widget.Toast;

public class NetworkReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);


        /*Network info*/
        if(connectivityManager.getActiveNetworkInfo() != null && connectivityManager.getActiveNetworkInfo().isConnected()){
            Toast.makeText(context, "Network is ON", Toast.LENGTH_LONG).show();
        }
        else{
            Toast.makeText(context, "Network is OFF", Toast.LENGTH_LONG).show();
        }
    }
}
