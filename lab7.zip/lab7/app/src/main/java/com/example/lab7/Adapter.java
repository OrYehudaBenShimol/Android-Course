package com.example.lab7;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.CountriesViewHolder>{

    public static  MediaPlayer mediaPlr;
    private final List<Country> countryList;
    private int selectedRow = -1;
    private Context cont;

    public Adapter(Context context) {
        this.countryList = CountryXMLParser.parseCountries(context);
        this.cont = context;
    }

    @Override
    public void onBindViewHolder(@NonNull Adapter.CountriesViewHolder holder, @SuppressLint("RecyclerView") int pos) {
        holder.bindData(countryList.get(pos));

        // This listener will change the color of selected row
        holder.nameTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectedRow = pos;
                notifyDataSetChanged();

            }
        });

        holder.countryItem.setOnClickListener(new DoubleClickListener() {
            @Override
            public void onDoubleClick() {
                String url = "http://www.google.com//search?q=" + countryList.get(pos).name;
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                cont.startActivity(i);
            }
        });
//        if(selectedRow == pos){
//            holder.rowLinearLayout.setBackgroundColor(Color.parseColor("#4D03dffc"));
//        }else{
//            holder.rowLinearLayout.setBackgroundColor(Color.parseColor("#4DFFFFFF"));
//        }
    }

    @Override
    public int getItemCount() {
        return countryList.size();
    }

    @NonNull
    @Override
    public CountriesViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View countryView = inflater.inflate(R.layout.country_item, parent, false);
        return new CountriesViewHolder(countryView);
    }


    public class CountriesViewHolder extends RecyclerView.ViewHolder {
        private final Context context;
        private final View countryItem;
        private final ImageView flagIV;
        private final TextView nameTV;
        private final TextView populationTV;
        private LinearLayout rowLinearLayout;
        private ImageButton play;
        private boolean flag = false;

        public CountriesViewHolder(@NonNull View itemView) {
            super(itemView);
            context = itemView.getContext();
            countryItem = itemView.findViewById(R.id.country_item);
            flagIV = itemView.findViewById(R.id.flagImageView);
            nameTV = itemView.findViewById(R.id.nameTextView);
            populationTV = itemView.findViewById(R.id.populationTextView);
            rowLinearLayout = itemView.findViewById(R.id.country_item);
            countryItem.setOnLongClickListener(view -> {
                removeCountry(getAdapterPosition());
                return true;
            });
            play = itemView.findViewById(R.id.play);
            play.setOnClickListener(view -> {
                playSound(getAdapterPosition());
            });
        }

        //******** This method connect the row widgets with the data
        public void bindData(Country country) {
            flagIV.setImageResource(getDrawableId(context, country.getFlag()));
            nameTV.setText(country.getName());
            populationTV.setText(country.getShorty());

        }

        private void removeCountry(int position) {
            countryList.remove(position);
            notifyItemRemoved(position);// ****** this notify to the recycle that there is change in data base
            Toast.makeText(context.getApplicationContext(),"Deleted!", Toast.LENGTH_SHORT).show();
            if(mediaPlr != null) {
                mediaPlr.stop();
                flag = false;
            }
        }

        public void playSound(int position) {
            Country a = countryList.get(position);
            String anthem = a.anthem;
            Uri uri = Uri.parse("android.resource://com.example.lab7/raw/" + anthem);

            if (flag == false) {
                mediaPlr = new MediaPlayer().create(context,uri);
                mediaPlr.start();
                flag = true;
            }
            else {
                if (mediaPlr != null) {
                    mediaPlr.stop();
                    flag = false;
                }
            }
        }
    }

    private static int getDrawableId(Context context, String drawableName) {
        Resources resources = context.getResources();
        return resources.getIdentifier(drawableName, "drawable", context.getPackageName());
    }

    /*This class is for double clicking fast*/
    public abstract class DoubleClickListener implements View.OnClickListener {

        // The time in which the second tap should be done in order to qualify as
        // a double click
        private static final long DEFAULT_QUALIFICATION_SPAN = 200;
        private long doubleClickQualificationSpanInMillis;
        private long timestampLastClick;

        public DoubleClickListener() {
            doubleClickQualificationSpanInMillis = DEFAULT_QUALIFICATION_SPAN;
            timestampLastClick = 0;
        }

        public DoubleClickListener(long doubleClickQualificationSpanInMillis) {
            this.doubleClickQualificationSpanInMillis = doubleClickQualificationSpanInMillis;
            timestampLastClick = 0;
        }

        @Override
        public void onClick(View v) {
            if((SystemClock.elapsedRealtime() - timestampLastClick) < doubleClickQualificationSpanInMillis) {
                onDoubleClick();
            }
            timestampLastClick = SystemClock.elapsedRealtime();
        }

        public abstract void onDoubleClick();

    }

}
