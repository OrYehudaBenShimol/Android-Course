package com.example.ex3a;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;

import androidx.appcompat.app.AppCompatActivity;

public class secondActivity extends AppCompatActivity {

    private String first_name;
    private String last_name;
    private EditText Et1;
    private EditText Et2;
    private RadioButton Rb1;
    private RadioButton Rb2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_for_activity_2);
        Et1= (EditText) findViewById(R.id.editTextTextPersonName);
        Et2 = (EditText) findViewById(R.id.editTextTextPersonName2);
        Rb1 = (RadioButton) findViewById(R.id.radioButton3);
        Rb2 = (RadioButton) findViewById(R.id.radioButton4);



    }

    public void sendBackFunc(View view){
        first_name = Et1.getText().toString();
        last_name = Et2.getText().toString();
        Intent intent = new Intent();
        if(first_name.length()>0 && last_name.length()>0 && (Rb1.isChecked() || Rb2.isChecked())){
            intent.putExtra("first_name", first_name);
            intent.putExtra("last_name", last_name);
            if(Rb1.isChecked())
                intent.putExtra("gender","Mr. ");
            else
                intent.putExtra("gender","Mrs.");

            setResult(RESULT_OK,intent);
            finish();
        }
    }
}
