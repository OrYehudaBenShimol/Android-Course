package com.example.ex3client;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.net.URI;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_ID = 1 ;
    private EditText call_text;
    private EditText surf_text;
    private EditText email_text;
    private EditText register_text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        register_text = (EditText) findViewById(R.id.editTextTextPersonName2);
    }

    private void makeToast(){
        Context context = getApplicationContext();
        Toast t = Toast.makeText(context,"Empty String" , Toast.LENGTH_SHORT);
        t.show();
    }

    public void call(View view){
        call_text = (EditText)findViewById(R.id.editTextPhone);
        Intent intent = new Intent(Intent.ACTION_DIAL);
        if(call_text.getText().toString().length() > 0) {
            intent.setData(Uri.parse("tel:" + call_text.getText().toString()));
            startActivity(intent);
        }
        else {
           makeToast();
        }
    }

    public void surf(View view){
        surf_text = (EditText)findViewById(R.id.editTextTextPersonName);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        if(surf_text.getText().toString().length() >0){
            String urlAddress = surf_text.getText().toString();
            if(!urlAddress.startsWith("http://") && !urlAddress.startsWith("https://"))
                urlAddress = "http://" + urlAddress;
            intent.setData(Uri.parse(urlAddress));
            startActivity(intent);
        }
        else{
            makeToast();
        }

    }

    public void email(View view){
        email_text = (EditText)findViewById(R.id.editTextTextEmailAddress);
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        if(email_text.getText().toString().length()>0){
            intent.setData(Uri.parse("mailto:" + email_text.getText().toString()));
            startActivity(intent);
        }
        else{
            makeToast();
        }
    }

    public void register(View view){
        Intent intent = new Intent();
        intent.setAction("com.action.register");
        startActivityForResult(intent,REQUEST_CODE_ID);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        if(requestCode == REQUEST_CODE_ID){
            if(resultCode== RESULT_OK){
                String first_name = intent.getStringExtra("first_name");
                String last_name = intent.getStringExtra("last_name");
                String gender = intent.getStringExtra("gender");
                register_text.setText("Welcome back "+gender +" " + first_name + " " + last_name) ;
            }
        }
    }
}