package com.example.ex2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private String operand1 ;
    private String operand2 ;
    private String operation ;
    private String result ;
    private TextView resText;
    private TextView operSym;
    private EditText Et1 ;
    private EditText Et2 ;
    private Button mul;
    private Button div;
    private Button plus;
    private Button sub;
    private Button eq;
    private Button clear;
    private  Context context;
    private boolean flag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Et1= (EditText) findViewById(R.id.editTextNumber);
        Et2 = (EditText) findViewById(R.id.editTextNumber2);
        resText = (TextView) findViewById(R.id.textView5);
        operSym = (TextView) findViewById(R.id.textView6);
        mul = (Button) findViewById(R.id.button2);
        div = (Button) findViewById(R.id.button3);
        plus = (Button) findViewById(R.id.button4);
        sub = (Button) findViewById(R.id.button5);
        clear = (Button) findViewById(R.id.button);
        context = getApplicationContext();
        if(result != ""){

        }
    }

    @Override
    public void onSaveInstanceState(Bundle outState)
    {
        outState.putString("res",resText.getText().toString());
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState)
    {
        super.onRestoreInstanceState(savedInstanceState);
        resText.setText(savedInstanceState.getString("res"));

    }

    public void editTextBox1(View v){
        operand1 = Et1.getText().toString();
    }
    public void editTextBox2(View v){
        operand2 = Et2.getText().toString();
    }

     public void multiplication(View v){
        operation = "X";
         operSym.setText(operation);
         calculate(operation);
     }

    public void divide(View v){
        operation = "div";
        operSym.setText("/");
        calculate(operation);
    }

    public void add(View v){
        operation = "+";
        operSym.setText(operation);
        calculate(operation);
    }

    public void subtract(View v){
        operation = "-";
        operSym.setText(operation);
        calculate(operation);
    }

    public void clearVal(View v){
        operand1 ="";
        operand2="";
        operation="";
        result="";
        Et1.setText("");
        Et2.setText("");
        resText.setText("");
        operSym.setText("");
        Toast toast = Toast.makeText(context,"Cleared!",Toast.LENGTH_SHORT);
        toast.show();
    }
    public void calculate(String op){
        operand1 = Et1.getText().toString();
        operand2 = Et2.getText().toString();
        if(operand1.length()>0 && operand2.length()>0 ){
            if(op == "div"  && Double.valueOf(operand2) == 0){
                Toast toast = Toast.makeText(context,"You Can't divide by zero",Toast.LENGTH_SHORT);
                toast.show();
                operSym.setText("");
            }
            else{
                if(op.equals("X") ){
                    result= String.valueOf(Double.valueOf(operand1) * Double.valueOf(operand2));
                    resText.setText(result);
                }

                if(op.equals("div")){
                    result = String.valueOf(Double.valueOf(operand1) / Double.valueOf(operand2));
                    resText.setText(result);
                }

                if(op.equals("+")){
                    result =String.valueOf(Double.valueOf(operand1) + Double.valueOf(operand2));
                    resText.setText(result);
                }

                if(op.equals("-")){
                    result =String.valueOf(Double.valueOf(operand1) - Double.valueOf(operand2));
                    resText.setText(result);
                }
            }
        }
        else{
            operSym.setText("");
            Toast toast = Toast.makeText(context,"Missing operands.",Toast.LENGTH_SHORT);
            toast.show();
        }
    }
}