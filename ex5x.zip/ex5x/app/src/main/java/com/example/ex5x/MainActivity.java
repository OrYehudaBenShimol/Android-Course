package com.example.ex5x;

import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentContainerView;


public class MainActivity extends AppCompatActivity implements FragA.FragAListener, FragB.FragBListener{
	FragB fragment2=new FragB() ;

	private FragA fragA;
	private FragB fragB;
	String field1 ="";
	String field2="";
	String result="";
	float sum = 0;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		fragA = (FragA) getSupportFragmentManager().findFragmentByTag("FRAGA");
		fragB = (FragB) getSupportFragmentManager().findFragmentByTag("FRAGB");

		if ((getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE)){
			if (fragB != null) {
				getSupportFragmentManager().beginTransaction()
						.show(fragB)
						.addToBackStack(null)
						.commit();
			}
			else {
				getSupportFragmentManager().beginTransaction()
						.add(R.id.fragB, FragB.class,null, "FRAGB")
						.commit();
			}
			getSupportFragmentManager().executePendingTransactions();
		}
	}


	@Override
	public void OnClickEvent(View btnId, String field1, String field2) {

		Bundle args = new Bundle();
		this.field1 = field1;
		this.field2=field2;
		String res = calculate(btnId.getId(),field1,field2);
		args.putString("field1", res);

		if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT)
			{
				getSupportFragmentManager().beginTransaction()
						.setReorderingAllowed(true)
						.add(R.id.fragContainer, FragB.class, null,"FRAGB")
						.addToBackStack("BBB")
						.commit();
				getSupportFragmentManager().executePendingTransactions();
			}
		fragment2 = (FragB) getSupportFragmentManager().findFragmentByTag("FRAGB");
		fragment2.setArguments(args);
		fragment2.onClick();
		}

	public String calculate(int btnId, String field1, String field2) {
		float num1 = Float.parseFloat(field1);
		float num2 = Float.parseFloat(field2);

		switch (btnId){
			case R.id.button_plus:
				result = String.valueOf(num1 + num2);
				break;
			case R.id.button_sub:
				result = String.valueOf(num1 - num2);
				break;
			case R.id.button_mul:
				result = String.valueOf((num1 * num2));

				break;
			case R.id.button_div:
				result = String.valueOf(num1 / num2);
				break;
		}

		return result;

	}

}
