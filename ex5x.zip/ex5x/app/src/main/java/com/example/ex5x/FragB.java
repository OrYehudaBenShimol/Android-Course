package com.example.ex5x;

//import android.app.Fragment;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class FragB extends Fragment {
	TextView tvValue;
	TextView example_tv;
	FragBListener listener;
	static int myInt = 0;
	SeekBar seek;
	String result = "";
	String final_str = "";
	private TextView resText;
	private TextView ExampleTxt;
	String field1="";


	@Override
	public void onCreate(@Nullable Bundle savedInstanceState) {
		setRetainInstance(false);
		super.onCreate(savedInstanceState);

	}

	@Override
	public void onAttach(@NonNull Context context) {
		try {
			this.listener = (FragBListener) context;
		} catch (ClassCastException e) {
			throw new ClassCastException("the class " +
					getActivity().getClass().getName() +
					" must implements the interface 'FragBListener'");
		}
		super.onAttach(context);
	}


	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
							 Bundle savedInstanceState) {
		return inflater.inflate(R.layout.frag_b, container, false);
	}


	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
	}

	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
		tvValue = (TextView)view.findViewById(R.id.textView6);
		ExampleTxt = (TextView) view.findViewById(R.id.textView100);
		seek = (SeekBar) view.findViewById(R.id.seekbar);
		seek.setEnabled(false);

		seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			Float tempRes = 0f;
			String tempTxt = "";

			@Override
			public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
				double ex = 123.0;
				tempRes = Float.valueOf(result);

					if (i == 0) {
						ExampleTxt.setText("Example: 123 ");
						tvValue.setText(String.valueOf(tempRes.intValue()));
					}
					if (i == 1) {
						ExampleTxt.setText("Example: " + String.format("%.1f",ex));
						tvValue.setText(String.format("%.1f", tempRes));

					}
					if (i == 2) {
						ExampleTxt.setText("Example: " + String.format("%.2f", ex));
						tvValue.setText(String.format("%.2f", tempRes));
					}
					if (i == 3) {
						ExampleTxt.setText("Example: " + String.format("%.3f", ex));
						tvValue.setText(String.format("%.3f", tempRes));
					}
					if (i == 4) {
						ExampleTxt.setText("Example: " + String.format("%.4f", ex));
						tvValue.setText(String.format("%.4f", tempRes));
					}
					if (i == 5) {
						ExampleTxt.setText("Example: " + String.format("%.5f", ex));
						tvValue.setText(String.format("%.5f", tempRes));
					}

			}

			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {

			}

			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
			}
		});
		super.onViewCreated(view, savedInstanceState);
	}

	//the activity informs fragB about new click in fragA
	public void onClick() {
		Bundle args = getArguments();

		if(args!=null) {
			field1 = args.getString("field1");
			seek.setEnabled(true);
			result = field1;
			Float tmp = Float.valueOf(result);
			tvValue.setText(String.valueOf(tmp.intValue()));

			ExampleTxt.setText("Example: 123");
		}

	}





	public interface FragBListener{
		//put here methods you want to utilize to communicate with the hosting activity
	}
}
