package com.example.ex5x;

//import android.app.Fragment;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class FragA extends Fragment {
	FragAListener listener;
	private EditText Et1 ;
	private EditText Et2 ;
	private Button mul;
	private Button div;
	private Button plus;
	private Button sub;
	private Button clear;
	private String operand1 = "" ;
	private String operand2 = "" ;
	private  Context context;

	@Override
	public void onAttach(@NonNull Context context) {
		try{
			this.listener = (FragAListener)context;
		}catch(ClassCastException e){
			throw new ClassCastException("the class " +
					context.getClass().getName() +
					" must implements the interface 'FragAListener'");
		}
		super.onAttach(context);
	}

	public interface FragAListener {
		void OnClickEvent(View btnId, String field1, String field2);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		return inflater.inflate(R.layout.frag_a, container,false);
	}

	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
		init();
		setListeners();
		super.onViewCreated(view, savedInstanceState);
	}

	private void init(){
		Et1 = getView().findViewById(R.id.editTextNumber);
		Et2= getView().findViewById(R.id.editTextNumber2);
		plus = getView().findViewById(R.id.button_plus);
		mul = getView().findViewById(R.id.button_mul);
		div = getView().findViewById(R.id.button_div);
		sub = getView().findViewById(R.id.button_sub);
		clear = getView().findViewById(R.id.button);
	}

	private void setListeners(){

		clear.setOnClickListener(view -> clearVal(view));

		plus.setEnabled(false);
		plus.setOnClickListener(view -> listener.OnClickEvent(view, Et1.getText().toString(), Et2.getText().toString()));
		mul.setEnabled(false);
		mul.setOnClickListener(view -> listener.OnClickEvent(view, Et1.getText().toString(), Et2.getText().toString()));
		div.setEnabled(false);
		div.setOnClickListener(view -> listener.OnClickEvent(view, Et1.getText().toString(), Et2.getText().toString()));
		sub.setEnabled(false);
		sub.setOnClickListener(view -> listener.OnClickEvent(view, Et1.getText().toString(), Et2.getText().toString()));

		Et1.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

			}

			@Override
			public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

			}

			@Override
			public void afterTextChanged(Editable editable) {
				if(!TextUtils.isEmpty(Et1.getText().toString()) && !TextUtils.isEmpty(Et2.getText().toString())){
					enableAllButton();
					if(Double.valueOf(Et2.getText().toString()) == 0){
						div.setEnabled(false);
					}
				}
				else disableAllButton();
			}
		});


		Et2.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
			}
			@Override
			public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
			}
			@Override
			public void afterTextChanged(Editable editable) {
				if(!TextUtils.isEmpty(Et2.getText().toString()) && !TextUtils.isEmpty(Et1.getText().toString())){
					double a = Double.valueOf(Et2.getText().toString());
					enableAllButton();
					if(a == 0) {
						div.setEnabled(false);
					}
				}
				else disableAllButton();
			}
		});
	}

	public void disableAllButton(){
		div.setEnabled(false);
		mul.setEnabled(false);
		sub.setEnabled(false);
		plus.setEnabled(false);
	}
	public void enableAllButton(){
		div.setEnabled(true);
		mul.setEnabled(true);
		sub.setEnabled(true);
		plus.setEnabled(true);
	}
	public void clearVal(View v){
		operand1 ="";
		operand2="";
		Et1.setText("");
		Et2.setText("");
		disableAllButton();
	}

}
