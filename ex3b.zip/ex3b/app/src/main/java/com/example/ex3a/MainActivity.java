package com.example.ex3a;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private static final int SECOND_ACTIVITY_REQUEST_CODE = 1;
    private TextView TV;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TV = (TextView)findViewById(R.id.textView);

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        if(requestCode == SECOND_ACTIVITY_REQUEST_CODE){
            if(resultCode== RESULT_OK){
                String first_name = intent.getStringExtra("first_name");
                String last_name = intent.getStringExtra("last_name");
                String gender = intent.getStringExtra("gender");
                TV.setText("Welcome back "+gender +" " + first_name + " " + last_name) ;
            }
        }
    }
    public void registerFunc(View view) {
        Intent intent = new Intent(this,secondActivity.class);
        startActivityForResult(intent, SECOND_ACTIVITY_REQUEST_CODE);
    }


}