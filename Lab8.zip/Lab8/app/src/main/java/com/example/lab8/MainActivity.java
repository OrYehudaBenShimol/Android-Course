
package com.example.lab8;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.ViewModelProvider;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.example.lab7.R;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    public static Viewmodel viewmodel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        viewmodel = new ViewModelProvider(this).get(Viewmodel.class); //CREATE VIEWMODEL
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //remove fragment...
        FragmentManager manager= getSupportFragmentManager();
        DetailsFragment fragment = (DetailsFragment) manager.findFragmentByTag("PORTRAIT");
        if (fragment != null) {
            manager.beginTransaction().detach(fragment).commit();
            manager.executePendingTransactions();
        }

    }

    @Override
    public boolean onCreateOptionsMenu(@NonNull Menu menu) {
        getMenuInflater().inflate(R.menu.settings_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        getSupportFragmentManager().beginTransaction()
                .setReorderingAllowed(true)
                .replace(R.id.ItemsFragment, new SettingsFragment()) //open the settings preference
                .addToBackStack(null) //without quiting the app
                .commit();
        getSupportFragmentManager().executePendingTransactions();

        return true;
    }
}