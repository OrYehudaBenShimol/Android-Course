package com.example.lab8;

import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class Viewmodel extends AndroidViewModel {

    private MutableLiveData<ArrayList<Country>> countries; //step 1
    private MutableLiveData<Integer> selectedItem;
    private Context context;
    private ArrayList<String> ignoredCountries;


    public MutableLiveData<ArrayList<Country>> getCountries(){
        ArrayList<Country> listOfCountries;
        boolean flag = context.getSharedPreferences("com.example.lab7_preferences", Context.MODE_PRIVATE).getBoolean("ignored",false);
        if(countries == null){ //  in case countries is null we have not created live data
            countries = new MutableLiveData<ArrayList<Country>>(); // step 2
            listOfCountries = CountryXMLParser.parseCountries(getApplication().getBaseContext());
            listOfCountries.removeIf(country -> (ignoredCountries.contains(country.name) && flag));//---------
            countries.setValue(listOfCountries); //creating the list observable , step 3
        }
        return countries;
    }

    public MutableLiveData<Integer> getSelectedItem(){
        if(selectedItem == null){
            selectedItem = new MutableLiveData<Integer>();
        }
        return selectedItem;
    }

    public Viewmodel(@NonNull Application application) {
        super(application);
        this.context = getApplication().getApplicationContext();
        ignoredCountries = this.readFromFile("sp"); //CHANGE TO RAW IF NEEDED
    }

    public void writeToFile(String data,String type) {
        if(type.equals("raw")) {
            try {
                OutputStreamWriter outputStreamWriter = new OutputStreamWriter(this.context.openFileOutput("ignoredCountries.txt", Context.MODE_APPEND));
                outputStreamWriter.write(data + '\n');
                outputStreamWriter.close();
            } catch (IOException e) {
                Log.e("Exception", "File write failed: " + e.toString());
            }
        }
        else{
            SharedPreferences sharedPref = context.getSharedPreferences("ignoredList", Context.MODE_PRIVATE); // Creating non-shared file
            SharedPreferences.Editor editor = sharedPref.edit();

            Set<String> set = (HashSet<String>) sharedPref.getStringSet("ignore",new HashSet<String>());
            Set<String> setCopy = new HashSet(set);
            setCopy.add(data);


            editor.putStringSet("ignore",setCopy);
            editor.apply();
        }
    }

    public ArrayList<String> readFromFile(String type) {

        ArrayList<String> ignoredCountries = new ArrayList<String>();
        if(type.equals("raw")) {
            try {
                InputStream inputStream = context.openFileInput("ignoredCountries.txt");

                if (inputStream != null) {
                    InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                    BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                    String receiveString = "";

                    while ((receiveString = bufferedReader.readLine()) != null) {
                        ignoredCountries.add(receiveString);
                    }

                    inputStream.close();
                }
            } catch (FileNotFoundException e) {
                Log.e("login activity", "File not found: " + e.toString());
            } catch (IOException e) {
                Log.e("login activity", "Can not read file: " + e.toString());
            }
        }
        else{
            SharedPreferences sharedPref = context.getSharedPreferences("ignoredList", Context.MODE_PRIVATE);
            Set<String> s = (Set<String>)sharedPref.getStringSet("ignore", Collections.singleton(""));
            ignoredCountries.addAll(s);
        }

        return ignoredCountries;
    }

    public void clearConfig() throws FileNotFoundException {
        File file = new File(this.context.getFilesDir(),"ignoredCountries.txt");
        PrintWriter pw = new PrintWriter(file);
        pw.close();
    }
}
