package com.example.lab8;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.lab7.R;

import java.util.ArrayList;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {
    
    private Viewmodel viewmodel;
    Context context;
    private ArrayList<Country> countries;
    private int selectedPos = RecyclerView.NO_POSITION;

    public Adapter(Context context, Viewmodel viewmodel) {
        this.context = context;
        this.viewmodel = viewmodel;
        //also in rotation ItemsFragment calls to this constructor and init the countries list with updated data from ViewModel instance
        countries = viewmodel.getCountries().getValue();

    }

    @NonNull
    @Override
    public Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        if (viewmodel.getSelectedItem().getValue() != null)
            selectedPos = viewmodel.getSelectedItem().getValue();
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.country_component, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Adapter.ViewHolder viewHolder, int i) {
        Resources resources = context.getResources();
        Country countryItem = countries.get(i);
        int resourceId = resources.getIdentifier(countryItem.getFlag(), "drawable", context.getPackageName());
        viewHolder.setData(countryItem, resourceId);
        // highlight the wanted line -------------------------------------------
        viewHolder.itemView.setSelected(selectedPos == i);
    }

    @Override
    public int getItemCount() {
        return countries.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView countryName;
        public TextView countryDescription;
        public ImageView countryImage;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            countryName = (TextView) itemView.findViewById(R.id.countryName);
            countryDescription = (TextView) itemView.findViewById(R.id.countryDescription);
            countryImage = (ImageView) itemView.findViewById(R.id.countryIMG);

            itemView.setOnLongClickListener(new View.OnLongClickListener() {

                @Override
                public boolean onLongClick(View v) {
                    String s = viewmodel.getCountries().getValue().get(getAbsoluteAdapterPosition()).name;
                    viewmodel.writeToFile(s,"sp"); // CHANGE TO RAW IF NEEDED
                    viewmodel.getCountries().getValue().remove(getAbsoluteAdapterPosition());
                    notifyItemRemoved(getAbsoluteAdapterPosition());
                    viewmodel.getSelectedItem().setValue(-1);
                    return true;
                }
            });


            itemView.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    notifyItemChanged(selectedPos);
                    // highlight the wanted line -------------------------------------------
                    selectedPos = getLayoutPosition();
                    notifyItemChanged(selectedPos);

                    //updating the live data that value have been changed
                    viewmodel.getSelectedItem().setValue(selectedPos);
                    // raising frag b
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    if (activity.getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
                        activity.getSupportFragmentManager().beginTransaction()
                                .add(R.id.ItemsFragment, new DetailsFragment(), "PORTRAIT")
                                .addToBackStack("Back")
                                .commit();
                    }
                }
            });
        }

        private void setData(Country countryItem, int resourceId) {
            countryName.setText(countryItem.getName());
            countryDescription.setText(countryItem.getShorty());
            countryImage.setImageResource(resourceId);
        }


    }


}
