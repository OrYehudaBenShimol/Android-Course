package com.example.lab8;

import android.content.res.Configuration;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModelProvider;

import com.example.lab7.R;

import java.util.Objects;

// we call to this class when we want to  raise fragb
public class DetailsFragment extends Fragment {
    Country selectedCountry;
    String selectedCountryData;
    int index;
    private Viewmodel viewModel;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.country_details, container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        viewModel = new ViewModelProvider(requireActivity()).get(Viewmodel.class); //getting the viewModel
        viewModel.getSelectedItem().observe(getViewLifecycleOwner(), index -> { //creating the class observable and telling him which function to excute while the data changed
            if(viewModel.getSelectedItem().getValue()==-1) {
                selectedCountryData = "Please select a country";
            }
            else {
                selectedCountry = Objects.requireNonNull(viewModel.getCountries().getValue()).get(index);
                selectedCountryData = selectedCountry.getDetails();
            }
            ((TextView) view.findViewById(R.id.textView)).setText(selectedCountryData.trim().replaceAll("  +", ""));
        });

        //if we chose a country - ie the livedata has been changed
        if (selectedCountry != null && getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            index = viewModel.getSelectedItem().getValue();
            selectedCountry = Objects.requireNonNull(viewModel.getCountries().getValue()).get(index);
            selectedCountryData = selectedCountry.getDetails();

        } else {
            selectedCountryData = "Please select a country";
        }
        ((TextView) view.findViewById(R.id.textView)).setText(selectedCountryData.trim().replaceAll("  +", ""));

    }
}
