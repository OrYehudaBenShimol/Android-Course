package com.example.ex5;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class Fragment1 extends Fragment {
    FragAListener listener;
    private EditText et1, et2;
    private Button addBtn, subBtn, mulBtn, divBtn;
    static String op1 = "", op2 = "";

    //override Fragment methods -----------------------------

    @Override
    public void onAttach(@NonNull Context context) {
        try {
            this.listener = (FragAListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException("the class " +
                    context.getClass().getName() +
                    " must implements the interface 'FragAListener'");
        }
        super.onAttach(context);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment1, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        initViews();
        setListeners();

        //for restore
        String saveOp2 = op2;
        et1.setText(op1);
        et2.setText(saveOp2);

        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    //interface must be implemented by listener-----------------------------
    public interface FragAListener {
        void OnClickEvent(View btnId, String field1, String field2);
    }

    //private methods-----------------------------
    private void setListeners() {
        addBtn.setOnClickListener(this::operationClickedHandler);
        subBtn.setOnClickListener(this::operationClickedHandler);
        mulBtn.setOnClickListener(this::operationClickedHandler);
        divBtn.setOnClickListener(this::operationClickedHandler);

        //attach an instance of member class that implements onClickListener interface to the operands (1-Member Class)
        et1.addTextChangedListener(new HandleOperandChange());
        et2.addTextChangedListener(new HandleOperandChange());

        //attach an instance of anonymous class that implements onClickListener interface to clear button(3- Anonymous Inner Class)
        getView().findViewById(R.id.Clear).setOnClickListener(arg0 -> {
            et1.setText("");
            et2.setText("");
        });

    }

    private void initViews() {
        et1 = getView().findViewById(R.id.op1);
        et2 = getView().findViewById(R.id.op2);
        addBtn = getView().findViewById(R.id.addBtn);
        subBtn = getView().findViewById(R.id.subBtn);
        mulBtn = getView().findViewById(R.id.mulBtn);
        divBtn = getView().findViewById(R.id.divBtn);
    }

    //handle with click button-----------------------------
    public void operationClickedHandler(View view) {
        listener.OnClickEvent(view, et1.getText().toString(), et2.getText().toString());
    }

    //inner class-----------------------------
    private class HandleOperandChange implements TextWatcher {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            String input1 = et1.getText().toString();
            String input2 = et2.getText().toString();
            Boolean enable = Utils.isValid(input1) && Utils.isValid(input2); //true if input is numeric and not empty
            addBtn.setEnabled(enable);
            subBtn.setEnabled(enable);
            mulBtn.setEnabled(enable);
            divBtn.setEnabled(enable && (Integer.parseInt(input2) != 0)); //enable if flag true and if 2nd input not equal to 0
        }

        @Override
        public void afterTextChanged(Editable s) {
            //for saving
            op1 = et1.getText().toString();
            op2 = et2.getText().toString();
        }
    }


}