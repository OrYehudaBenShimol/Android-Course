package com.example.ex5;

import androidx.fragment.app.Fragment;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public class Fragment2 extends Fragment implements SeekBar.OnSeekBarChangeListener {

    FragBListener listener;
    private TextView displayTv;
    private TextView exampleTextView;
    static String format = "%.1f";
    static Float res;
    static int seekBarProgress = 1;
    static String calcStr="";

    //override Fragment methods -----------------------------
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        setRetainInstance(false);
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        try {
            this.listener = (FragBListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException("the class " +
                    getActivity().getClass().getName() +
                    " must implements the interface 'FragBListener'");
        }
        super.onAttach(context);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment2, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {

        ((SeekBar) getView().findViewById(R.id.seekBar)).setOnSeekBarChangeListener(this);
        getViewsByIds(view);
        ((SeekBar) getView().findViewById(R.id.seekBar)).setProgress(seekBarProgress);
        //restore
        setExampleTextView();
        if (res != null)
            displayTv.setText(calcStr + String.format(format, res)); //res is always equal to last result of calculation

        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    //implementation of OnSeekBarChangeListener-----------------------------
    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        seekBarProgress = progress;
        format = "%." + seekBarProgress + "f";

        setExampleTextView();
        if (res != null)
            displayTv.setText(calcStr + String.format(format, res)); //res is always equal to last result of calculation
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {
    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {
    }

    //private methods-----------------------------
    private void setExampleTextView() {
        StringBuilder exampleStr = new StringBuilder(getString(R.string.app_name));
        exampleStr.append(String.format(format, 123.0));
        exampleTextView.setText(exampleStr);
    }

    private void getViewsByIds(View view) {
        displayTv = view.findViewById(R.id.display);
        exampleTextView = view.findViewById(R.id.exampleTv);

    }
    //the activity informs fragment2 about new click in fragment1
    public void onClick() {
        Bundle args = getArguments();
        if (args != null) {
            String field1 = args.getString("field1");
            String field2 = args.getString("field2");
            int btnId = args.getInt("btnId");
            displayTv.setText(buttonClickHandler(btnId, field1, field2));
        }
    }

    public static String buttonClickHandler(int btnId, String field1, String field2) {
        float n1, n2;
        n1 = Float.parseFloat(field1);
        n2 = Float.parseFloat(field2);
        switch (btnId) {
            case R.id.addBtn:
                res = n1 + n2;
                calcStr = (int) n1 + "+" + (int) n2 + "=";
                break;
            case R.id.subBtn:
                res = n1 - n2;
                calcStr = (int) n1 + "-" + (int) n2 + "=";
                break;
            case R.id.mulBtn:
                res = n1 * n2;
                calcStr = (int) n1 + "*" + (int) n2 + "=";
                break;
            case R.id.divBtn:
                res = n1 / n2;
                calcStr = (int) n1 + "/" + (int) n2 + "=";
                break;

        }
        return calcStr + String.format(format, res);
    }
    public interface FragBListener {
    }
}
