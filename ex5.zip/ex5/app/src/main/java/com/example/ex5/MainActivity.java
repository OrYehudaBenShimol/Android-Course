package com.example.ex5;
import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;


public class MainActivity extends AppCompatActivity implements Fragment1.FragAListener, Fragment2.FragBListener {
    Fragment2 fragment2=new Fragment2() ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public void OnClickEvent(View btnId, String field1, String field2) {
        Bundle args = new Bundle();
        args.putInt("btnId", btnId.getId());
        args.putString("field1", field1);
        args.putString("field2", field2);

        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            getSupportFragmentManager().beginTransaction()
                    .setReorderingAllowed(true)
                    .add(R.id.fragContainer, fragment2, "frag2")
                    .addToBackStack(null)
                    .commit();
            getSupportFragmentManager().executePendingTransactions();
        }
        fragment2 = (Fragment2) getSupportFragmentManager().findFragmentByTag("frag2");
        fragment2.setArguments(args);
        fragment2.onClick();

    }

}