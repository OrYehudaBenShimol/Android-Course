package com.example.ex5;

import java.util.regex.Pattern;

public class Utils {
    private static final Pattern pattern = Pattern.compile("-?\\d+(\\.\\d+)?");

    public static boolean isNumeric(String strNum) {
        if (strNum == null) {
            return false;
        }
        return pattern.matcher(strNum).matches();
    }

    public static boolean isValid(String input1) {
        return !input1.isEmpty() && isNumeric(input1);
    }



}


